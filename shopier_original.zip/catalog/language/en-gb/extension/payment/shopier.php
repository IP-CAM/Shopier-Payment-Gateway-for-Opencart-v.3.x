<?php
// Text
$_['text_title']				= 'Shopier Payment Gateway';
$_['thank_you_choose']			= 'Thank you for Choosing Shopier Payment Gateway to make the payment';
$_['please_wait']			= 'Please wait, we are now redirecting you to Payment Gateway.';
$_['trans_declined']			= 'Transaction Declined: ';
$_['sec_error']			= 'Security Error. Illegal access detected.';

// Returned text
$_['button_confirm']	= 'Confirm Order';
