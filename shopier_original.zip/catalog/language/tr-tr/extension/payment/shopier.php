<?php
// Text
$_['text_title']				= 'Kredi Kartı ile Ödeme';
$_['thank_you_choose']			= 'Ödeme için teşekkür ederiz';
$_['please_wait']			= 'Lütfen bekleyin, ödeme arayüzüne yönlendiriliyorsunuz.';
$_['trans_declined']			= 'İşlem reddedildi: ';
$_['sec_error']			= 'Güvenlik hatası, yetkisiz erişim tespit edildi.';

// Returned text
$_['button_confirm']	= 'Ödemeyi onayla';
