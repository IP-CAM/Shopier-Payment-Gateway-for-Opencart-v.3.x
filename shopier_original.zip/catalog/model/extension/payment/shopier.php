<?php

class ModelExtensionPaymentShopier extends Model {

	public function getMethod($address, $total) {
		$this->load->language('extension/payment/shopier');

		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "zone_to_geo_zone` WHERE geo_zone_id = '" . (int)$this->config->get('shopier_geo_zone_id') . "' AND country_id = '" . (int)$address['country_id'] . "' AND (zone_id = '" . (int)$address['zone_id'] . "' OR zone_id = '0')");

		if (!$this->config->get('shopier_geo_zone_id')) {
			$status = true;
		} elseif ($query->num_rows) {
			$status = true;
		} else {
			$status = false;
		}

		$method_data = array();

		if ($status) {
			$method_data = array(
				'code' => 'shopier',
				'title' => $this->language->get('text_title'),
				'terms' => '',
				'sort_order' => $this->config->get('shopier_sort_order')
			);
		}

		return $method_data;
	}

	public function getOrderProducts($order_id) {

		return $this->db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = '" . (int)$order_id . "'");
	}
	
	public function isVirtual($product_id) {

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_to_download WHERE product_id = '" . (int)$product_id . "'");
		if ($query->num_rows) {
			$status = true;
		} else {
			$status = false;
		}
		return $status;
	}

	public function addTransaction($order_id, $payment_id, $installment) {
		$this->db->query("INSERT INTO `" . DB_PREFIX . "shopier_payments` SET `order_id` = '" . $order_id . "', payment_id = '" . $payment_id . "', installment = '" . $installment . "'");
	}

}
