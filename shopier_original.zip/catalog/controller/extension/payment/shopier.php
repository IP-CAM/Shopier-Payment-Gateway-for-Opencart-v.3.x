<?php
class ControllerExtensionPaymentShopier extends Controller {
	public function index() {
		$this->load->language('extension/payment/shopier');

		$data['thank_you_choose'] = $this->language->get('thank_you_choose');
		$data['please_wait'] = $this->language->get('please_wait');
		$data['button_confirm'] = $this->language->get('button_confirm');
		
		$this->load->model('checkout/order');
		$this->load->model('account/customer');
		$this->load->model('extension/payment/shopier');
		
		$order_id = $this->session->data['order_id'];
		$order_info = $this->model_checkout_order->getOrder($order_id);

        $customer_id = $order_info['customer_id'];
		$buyer_account_age = 0;
		if ($customer_id > 0) {
			$customer =  $this->model_account_customer->getCustomer($customer_id);
			$user_registered = $customer['date_added'];
			$time_elapsed = time() - strtotime($user_registered);
			$buyer_account_age = (int)($time_elapsed/86400);
		}
        $currency = $order_info['currency_code'];
        if ($currency == 'USD') {
            $currency = 1;
        } elseif ($currency == 'EUR') {
            $currency = 2;
        } else {
            $currency = 0;
        }
        $productinfo = "";
        $producttype = '2';
        $items = $this->model_extension_payment_shopier->getOrderProducts($order_id);
        foreach ($items->rows as $item) {
            $productinfo .= $item['name'].';';
			if($producttype != 0 && $this->model_extension_payment_shopier->isVirtual($item['product_id'])){
				$producttype = 1;
			} else {
				$producttype = 0;
			}
        }
		
		if ($producttype == 0 && empty($order_info['shipping_address_1'])) {
			$producttype = 1;
		}

        $billingPhone = $order_info['telephone'];
		$billingAddress = $order_info['payment_address_1'];
        if (!empty($order_info['payment_address_2'])) {
            $billingAddress .= ' '.$order_info['payment_address_1'];
        }
        if ($order_info['payment_zone']) {
            $billingAddress .= ' '.$order_info['payment_zone'];
        }
        $billingCountry = $order_info['payment_country'];
		$shippingAddress = $order_info['shipping_address_1'];
        if (!empty($order_info['shipping_address_2'])) {
            $shippingAddress .= ' '.$order_info['shipping_address_1'];
        }
        if ($order_info['shipping_zone']) {
            $shippingAddress .= ' '.$order_info['shipping_zone'];
        }
        $shippingCountry = $order_info['shipping_country'];
		
		$productinfo = str_replace('"','',$productinfo);
		$productinfo = str_replace('&quot;','',$productinfo);
		$amount = round($this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false),2);
        $current_lang= $this->language->get('code');
		$current_lan=1;
		if ($current_lang == "tr") $current_lan=0;
		$modul_version=1.7;
		srand(time());
		$args = array
        (
            'API_key' => $this->config->get('payment_shopier_api_key'),
			'website_index' =>$this->config->get('payment_shopier_website_index'),
			//'sort_order' =>$this->config->get('payment_shopier_sort_order'),
            'platform_order_id' => $order_id,
            'product_name' => $productinfo,
            'product_type' => $producttype,
            'buyer_name' => $order_info['firstname'],
            'buyer_surname' => $order_info['lastname'],
            'buyer_email' => $order_info['email'],
            'buyer_account_age' => $buyer_account_age,
            'buyer_id_nr' => $customer_id,
            'buyer_phone' => $billingPhone,
            'billing_address' => $billingAddress,
            'billing_city' => $order_info['payment_city'],
            'billing_country' => $billingCountry,
            'billing_postcode' => $order_info['payment_postcode'],
            'shipping_address' => $shippingAddress,
            'shipping_city' => $order_info['shipping_city'],
            'shipping_country' => $shippingCountry,
            'shipping_postcode' => $order_info['shipping_postcode'],
            'total_order_value' => $amount,
            'currency' => $currency,
            'platform' => 1,
            'is_in_frame' => 0,
			'current_language' => $current_lan,
			'modul_version' =>$modul_version,
			'random_nr' => rand(100000,999999)
        );

        $params = implode('', $args);
        $signature = hash_hmac('SHA256',$args['random_nr'].$args['platform_order_id'].$args['total_order_value'].$args['currency'],$this->config->get('payment_shopier_secret'),true);
        $signature = base64_encode($signature);
        $args['signature'] = $signature;
		
		$data['params'] = $args;
		$data['payment_url'] = $this->config->get('payment_shopier_payment_url');

		return $this->load->view('extension/payment/shopier', $data);
	}

	public function response() {
		$this->load->language('extension/payment/shopier');
		
		if (isset($_REQUEST['platform_order_id'])) {
			$order_id = $_REQUEST['platform_order_id'];
			$status = $_REQUEST['status'];
			
			if ($order_id != '') {
				try {
					$this->load->model('checkout/order');
					$this->load->model('extension/payment/shopier');
					
					
					$data = '';
					$data=$_REQUEST['random_nr'].$_REQUEST['platform_order_id'];
					$signature = base64_decode($_POST["signature"]);
					$expected=hash_hmac('SHA256',$data,$this->config->get('payment_shopier_secret'),true);
					if ($signature == $expected) 
					{
						$status = strtolower($status);
						if ($status=="success") 
						{
							$payment_id = $_REQUEST['payment_id'];
							$installment = $_REQUEST['installment'];
							$this->model_checkout_order->addOrderHistory($order_id, 15, 'Shopier Payment Id: '.$payment_id.'; Installment: '.$installment);
							$this->model_extension_payment_shopier->addTransaction($order_id, $payment_id, $installment);
							$this->response->redirect($this->url->link('checkout/success', '', true));
						} 
						else 
						{
							$message = $this->language->get('trans_declined');
							$message .= $_POST['error_message'];
							$this->session->data['error'] = $message;
							$this->response->redirect($this->url->link('checkout/checkout', '', true));
						}
					}
					else 
					{
						$message = $this->language->get('sec_error');
						$this->session->data['error'] = $message;
						$this->response->redirect($this->url->link('checkout/checkout', '', true));
					}
				} catch(Exception $e){
					$message = $e->getMessage();
					$this->session->data['error'] = $message;
					$this->response->redirect($this->url->link('checkout/checkout', '', true));
				}
			}
			else 
			{
				$message = $this->language->get('sec_error');
				$this->session->data['error'] = $message;
				$this->response->redirect($this->url->link('checkout/checkout', '', true));
			}
		}
		else 
		{
			$message = $this->language->get('sec_error');
			$this->session->data['error'] = $message;
			$this->response->redirect($this->url->link('checkout/checkout', '', true));
		}
	}

}