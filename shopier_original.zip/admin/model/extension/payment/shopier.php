<?php
class ModelExtensionPaymentShopier extends Model {
	public function install() {
		$this->db->query("
			CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "shopier_payments` (
			  `order_id` INT(11) NOT NULL,
			  `payment_id` VARCHAR(50),
			  `installment` VARCHAR(50)
			) ENGINE=MyISAM DEFAULT COLLATE=utf8_general_ci;");
	}

	public function uninstall() {
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "shopier_payments`;");
	}

	public function getTransaction($order_id) {
		return $this->db->query("SELECT * FROM `" . DB_PREFIX . "shopier_payments` WHERE `order_id` = '" . (int)$order_id . "'");
	}
}
