<?php
// Heading
$_['heading_title']			 = 'Shopier Payment Gateway';

// Text
$_['text_extension']		 = 'Extensions';
$_['text_success']			 = 'Success: You have modified Shopier Payment Gateway account details!';
$_['text_edit']              = 'Edit Shopier Payment Gateway';
$_['text_shopier']	 		= '<img src="view/image/payment/shopier.png" alt="Shopier Payment Gateway" title="Shopier Payment Gateway" style="border: 1px solid #EEEEEE;" />';

// Entry
$_['entry_vendor']			 = 'Api Key';
$_['entry_secret_key']		 = 'Secret';
$_['entry_payment_url']		= 'Payment Endpoint URL';
$_['entry_website_index']      = 'Website Index';
$_['entry_geo_zone']		 = 'Geo Zone';
$_['entry_status']			 = 'Status';
$_['entry_sort_order']		 = 'Sort Order';
$_['entry_response_url']		 = 'Please paste this URL in your Shopier panel (Integrations-> Module Management page): ';

// Description
$_['description_response_url'] = 'In standard usage, you don\'t need to change this field.';
$_['description_website_index'] = 'If you are only using it on one site, this field should be 1. If you use more than 1 site, follow the setup guide for setting this field.';
$_['description_access_shopier'] = 'This obtained by user from Shopier panel.';

// Error
$_['error_permission']		 = 'Warning: You do not have permission to modify payment Shopier!';
$_['error_api_key']		 	= 'Api Key Required!';
$_['error_secret']			 = 'Secret Required!';
$_['error_payment_url']		= 'Payment Endpoint URL Required!';
$_['error_shipping_url']	   = 'Shipping Endpoint URL Required!';
$_['error_cancel_url']		 = 'Cancel Endpoint URL Required!';