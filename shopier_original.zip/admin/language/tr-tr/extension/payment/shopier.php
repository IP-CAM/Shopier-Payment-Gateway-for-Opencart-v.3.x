<?php
// Heading
$_['heading_title']			 = 'Shopier Ödeme Sistemi';

// Text
$_['text_extension']		 = 'Eklentiler';
$_['text_success']			 = 'Shopier ayarlarınız güncellenmiştir!';
$_['text_edit']              = 'Shopier ayarlarını düzenle';
$_['text_shopier']	 		= '<img src="view/image/payment/shopier.png" alt="Shopier Ödeme Arabirimi" title="Shopier Ödeme Arabirimi" style="border: 1px solid #EEEEEE;" />';

// Entry
$_['entry_vendor']			 = 'API Key';
$_['entry_secret_key']		 = 'API Secret';
$_['entry_payment_url']		= 'Ödeme URL';
$_['entry_website_index']      = 'Website Index';
$_['entry_geo_zone']		 = 'Geo Zone';
$_['entry_status']			 = 'Durum';
//$_['entry_sort_order']		 = 'Sıralama';
$_['entry_response_url']		 = 'Bu URL adresini Shopier panelinde Entegrasyonlar->Modül Yönetimi sayfasına yapıştırınız: ';

// Description
$_['description_response_url'] = 'Standart kullanımda, bu alanı değiştirmeniz gerekmemektedir.';
$_['description_website_index'] = 'Sadece tek bir sitede kullanıyorsanız, bu alan 1 olmalıdır. 1 den fazla sitede kullanıyorsanız, bu alanın ayarı için kurulum kılavuzunu takip ediniz.';
$_['description_access_shopier'] = 'Shopier Panelinden erişelebilir.';

// Error
$_['error_permission']		 = 'Bu alanı değiştirmeye yetkiniz yok!';
$_['error_api_key']		 	= 'Api Kullanıcı zorunlu alandır!';
$_['error_secret']			 = 'API Şifre zorunlu alandır!';
$_['error_payment_url']		= 'Ödeme URL zorunlu alandır!';
$_['error_website_index']    ='Website Index zorunlu alandır';